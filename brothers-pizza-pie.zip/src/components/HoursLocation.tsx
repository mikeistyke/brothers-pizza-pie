import { useState } from 'react';
import { Check, Clock, Copy, MapPin, Navigation, Phone } from 'lucide-react';
import { getStauntonOpenStatus, RESTAURANT } from '../data/restaurant';

export function HoursLocation() {
  const [copiedField, setCopiedField] = useState<'address' | 'phone' | null>(null);
  const status = getStauntonOpenStatus();

  const handleCopy = async (value: string, field: 'address' | 'phone') => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedField(field);
      window.setTimeout(() => {
        setCopiedField((current) => (current === field ? null : current));
      }, 2200);
    } catch {
      setCopiedField(null);
    }
  };

  return (
    <section id="location" className="border-b border-stone-200 bg-white">
      <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-18 lg:px-8 lg:py-20">
        <div className="max-w-2xl">
          <p className="text-sm font-semibold text-[#00703C]">Visit or Call</p>
          <h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-zinc-950 sm:text-4xl text-balance">
            Hours &amp; Location
          </h2>
          <p className="mt-3 text-base text-zinc-600">
            Find us in Staunton, Virginia for fresh hand-tossed pies and appetizers, or call ahead
            for fast pickup.
          </p>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-6 lg:grid-cols-3 lg:gap-8">
          {/* Card 1: Location & Directions (Green) */}
          <div className="flex flex-col justify-between rounded-2xl border border-[#00703C]/25 bg-stone-50 p-6 sm:p-8">
            <div>
              <div className="flex items-center gap-3">
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-[#00703C] text-white">
                  <MapPin className="h-5 w-5" aria-hidden="true" />
                </span>
                <h3 className="font-display text-xl font-semibold text-zinc-950">Location</h3>
              </div>

              <address className="mt-5 not-italic text-base leading-relaxed text-zinc-800">
                <span className="block font-semibold text-zinc-950">{RESTAURANT.name}</span>
                <span className="block">{RESTAURANT.address.street}</span>
                <span className="block">
                  {RESTAURANT.address.city}, {RESTAURANT.address.state}{' '}
                  <span className="tabular-nums">{RESTAURANT.address.zip}</span>
                </span>
              </address>
            </div>

            <div className="mt-6 flex flex-col gap-2.5 border-t border-stone-200 pt-5 sm:flex-row">
              <a
                href={RESTAURANT.address.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-lg bg-[#00703C] px-4 py-2.5 text-sm font-semibold text-white whitespace-nowrap hover:bg-[#005930] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#00703C] transition-colors duration-150"
              >
                <Navigation className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>Get Directions</span>
              </a>

              <button
                type="button"
                onClick={() => handleCopy(RESTAURANT.address.full, 'address')}
                aria-label="Copy street address"
                className="inline-flex min-h-[44px] items-center justify-center gap-1.5 rounded-lg border border-stone-300 bg-white px-3.5 py-2.5 text-sm font-medium text-zinc-800 whitespace-nowrap hover:bg-stone-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-800 transition-colors duration-150"
              >
                {copiedField === 'address' ? (
                  <>
                    <Check className="h-4 w-4 text-emerald-700" aria-hidden="true" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4 text-zinc-500" aria-hidden="true" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Card 2: Weekly Hours (White) */}
          <div className="flex flex-col justify-between rounded-2xl border border-stone-200 bg-white p-6 sm:p-8">
            <div>
              <div className="flex items-center gap-3">
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-stone-200 bg-stone-50 text-zinc-900">
                  <Clock className="h-5 w-5" aria-hidden="true" />
                </span>
                <h3 className="font-display text-xl font-semibold text-zinc-950">Hours</h3>
              </div>

              <dl className="mt-5 divide-y divide-stone-200 text-sm">
                {RESTAURANT.hours.map((row) => (
                  <div key={row.label} className="flex items-center justify-between gap-4 py-2.5">
                    <dt className="font-medium text-zinc-700">{row.label}</dt>
                    <dd className="font-semibold text-zinc-950 tabular-nums">{row.display}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <div className="mt-6 border-t border-stone-200 pt-5 text-sm">
              <p
                className={`font-semibold ${
                  status.isOpen ? 'text-[#00703C]' : 'text-zinc-800'
                }`}
              >
                {status.label} <span aria-hidden="true">·</span>{' '}
                <span className="font-normal text-zinc-600 tabular-nums">{status.detail}</span>
              </p>
            </div>
          </div>

          {/* Card 3: Phone Orders (Red) */}
          <div className="flex flex-col justify-between rounded-2xl border border-red-900/20 bg-stone-50 p-6 sm:p-8">
            <div>
              <div className="flex items-center gap-3">
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-red-800 text-white">
                  <Phone className="h-5 w-5" aria-hidden="true" />
                </span>
                <h3 className="font-display text-xl font-semibold text-zinc-950">Phone Orders</h3>
              </div>

              <p className="mt-5 text-2xl font-bold tracking-tight text-zinc-950 tabular-nums">
                <a
                  href={RESTAURANT.phone.href}
                  className="hover:text-red-800 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-red-800"
                >
                  {RESTAURANT.phone.display}
                </a>
              </p>
              <p className="mt-2 text-sm leading-relaxed text-zinc-600">
                All orders are placed directly by phone so our kitchen can prepare your pies and
                appetizers fresh.
              </p>
            </div>

            <div className="mt-6 flex flex-col gap-2.5 border-t border-stone-200 pt-5 sm:flex-row">
              <a
                href={RESTAURANT.phone.href}
                className="inline-flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-lg bg-red-800 px-4 py-2.5 text-sm font-semibold text-white whitespace-nowrap hover:bg-red-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-800 transition-colors duration-150 tabular-nums"
              >
                <Phone className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>Call Now</span>
              </a>

              <button
                type="button"
                onClick={() => handleCopy(RESTAURANT.phone.display, 'phone')}
                aria-label="Copy phone number"
                className="inline-flex min-h-[44px] items-center justify-center gap-1.5 rounded-lg border border-stone-300 bg-white px-3.5 py-2.5 text-sm font-medium text-zinc-800 whitespace-nowrap hover:bg-stone-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-800 transition-colors duration-150"
              >
                {copiedField === 'phone' ? (
                  <>
                    <Check className="h-4 w-4 text-emerald-700" aria-hidden="true" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4 text-zinc-500" aria-hidden="true" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        <p className="sr-only" aria-live="polite">
          {copiedField === 'address'
            ? 'Address copied to clipboard.'
            : copiedField === 'phone'
              ? 'Phone number copied to clipboard.'
              : ''}
        </p>
      </div>
    </section>
  );
}
