import { Phone } from 'lucide-react';
import { RESTAURANT } from '../data/restaurant';
import { ItalianFlagBanner } from './ItalianFlagWave';

export function OrderCta() {
  return (
    <section id="order" className="border-b border-stone-200 bg-stone-50">
      <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-16 lg:px-8">
        <div className="overflow-hidden rounded-2xl border border-stone-200 bg-white">
          <ItalianFlagBanner className="pt-2" />
          <div className="flex flex-col items-start justify-between gap-8 p-6 sm:p-10 lg:flex-row lg:items-center">
            <div className="max-w-xl">
              <p className="text-sm font-semibold text-[#00703C]">Order by Phone</p>
            <h2 className="mt-2 font-display text-2xl font-bold tracking-tight text-zinc-950 sm:text-3xl text-balance">
              Ready for a fresh hand-tossed pie? Call our kitchen directly.
            </h2>
            <p className="mt-3 text-base text-zinc-600">
              All orders are taken by phone for now. Tap below on mobile or dial{' '}
              <span className="font-semibold text-zinc-900 tabular-nums">
                {RESTAURANT.phone.display}
              </span>{' '}
              to place your pickup order at {RESTAURANT.address.street}.
            </p>
          </div>

            <div className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
              <a
                href={RESTAURANT.phone.href}
                className="inline-flex min-h-[52px] items-center justify-center gap-2.5 rounded-lg bg-red-800 px-7 py-3.5 text-base font-semibold text-white whitespace-nowrap shrink-0 hover:bg-red-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-800 transition-colors duration-150 tabular-nums"
              >
                <Phone className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>Call {RESTAURANT.phone.display}</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
