import { RESTAURANT } from '../data/restaurant';
import { ItalianFlagEmblem } from './ItalianFlagWave';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-white">
      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-6 border-b border-stone-200 pb-8 md:flex-row md:items-center">
          <div>
            <div className="flex items-center gap-3">
              <ItalianFlagEmblem className="h-6 w-9 shrink-0" />
              <p className="font-display text-lg font-bold text-zinc-950">{RESTAURANT.name}</p>
            </div>
            <p className="mt-1 text-sm text-zinc-600 tabular-nums">
              {RESTAURANT.address.full} <span aria-hidden="true">·</span>{' '}
              <a
                href={RESTAURANT.phone.href}
                className="font-medium text-zinc-800 hover:text-red-800 hover:underline"
              >
                {RESTAURANT.phone.display}
              </a>
            </p>
          </div>

          <nav aria-label="Footer navigation" className="flex flex-wrap gap-6 text-sm text-zinc-600">
            <a href="#menu" className="hover:text-zinc-950 hover:underline">
              Signature Dishes
            </a>
            <a href="#about" className="hover:text-zinc-950 hover:underline">
              Our Story
            </a>
            <a href="#location" className="hover:text-zinc-950 hover:underline">
              Hours &amp; Location
            </a>
            <a href="#order" className="hover:text-zinc-950 hover:underline">
              Order by Phone
            </a>
          </nav>
        </div>

        <div className="mt-6 flex flex-col justify-between gap-2 text-xs text-zinc-500 sm:flex-row sm:items-center">
          <p className="tabular-nums">
            &copy; {currentYear} {RESTAURANT.name} <span aria-hidden="true">·</span>{' '}
            <span>{RESTAURANT.domain}</span> <span aria-hidden="true">·</span> Staunton, Virginia
          </p>
          <p>
            Site architect:{' '}
            <a
              href={RESTAURANT.architect.url}
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-zinc-700 hover:text-[#00703C] hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#00703C]"
            >
              {RESTAURANT.architect.name} · {RESTAURANT.architect.agency}
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
