import { useState } from 'react';
import { Phone, X } from 'lucide-react';
import {
  RESTAURANT,
  SIGNATURE_DISHES,
  type DishCategory,
  type SignatureDishSlot,
} from '../data/restaurant';
import { DishArtwork } from './DishArtwork';

const CATEGORIES: DishCategory[] = ['All', 'Hand-Tossed Pies', 'Appetizers'];

export function SignatureDishes() {
  const [activeCategory, setActiveCategory] = useState<DishCategory>('All');
  const [selectedDish, setSelectedDish] = useState<SignatureDishSlot | null>(null);

  const visibleDishes =
    activeCategory === 'All'
      ? SIGNATURE_DISHES
      : SIGNATURE_DISHES.filter((dish) => dish.category === activeCategory);

  return (
    <section id="menu" className="border-b border-stone-200 bg-white">
      <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-18 lg:px-8 lg:py-20">
        <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold text-[#00703C]">Menu Highlights</p>
            <h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-zinc-950 sm:text-4xl text-balance">
              Signature Dishes Gallery
            </h2>
            <p className="mt-3 text-base text-zinc-600">
              A look at our signature hand-tossed pies and house appetizers. Call{' '}
              <a
                href={RESTAURANT.phone.href}
                className="font-semibold text-red-800 hover:underline tabular-nums"
              >
                {RESTAURANT.phone.display}
              </a>{' '}
              for today&rsquo;s selections and phone orders.
            </p>
          </div>

          {/* Interactive category filter tabs */}
          <div
            role="group"
            aria-label="Filter signature dishes"
            className="inline-flex self-start rounded-lg bg-stone-100 p-1"
          >
            {CATEGORIES.map((category) => {
              const isActive = activeCategory === category;
              return (
                <button
                  key={category}
                  type="button"
                  onClick={() => setActiveCategory(category)}
                  aria-pressed={isActive}
                  className={`min-h-[40px] rounded-md px-3.5 py-2 text-xs sm:text-sm font-medium whitespace-nowrap shrink-0 transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#00703C] ${
                    isActive
                      ? 'bg-[#00703C] text-white shadow-sm'
                      : 'text-zinc-600 hover:text-zinc-950'
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>
        </div>

        {/* 3-column signature dish gallery grid */}
        <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 lg:gap-8">
          {visibleDishes.map((dish) => (
            <button
              key={dish.id}
              type="button"
              onClick={() => setSelectedDish(dish)}
              className="group flex flex-col overflow-hidden rounded-xl border border-stone-200 bg-stone-50 text-left transition-transform duration-150 hover:-translate-y-0.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-800"
            >
              <div className="relative aspect-[4/3] w-full overflow-hidden border-b border-stone-200 bg-stone-100">
                <DishArtwork variant={dish.variant} />
                <span className="absolute bottom-3 right-3 text-xs font-medium text-zinc-500 tabular-nums">
                  Photo {dish.slotNumber}
                </span>
              </div>

              <div className="flex flex-1 flex-col justify-between p-5">
                <div>
                  <p className="text-xs font-medium text-zinc-500">
                    {dish.category} <span aria-hidden="true">·</span> Gallery Slot {dish.slotNumber}
                  </p>
                  <h3 className="mt-1.5 font-display text-lg font-semibold text-zinc-950 group-hover:text-red-800 transition-colors duration-150">
                    {dish.title}
                  </h3>
                  <p className="mt-1 text-sm text-zinc-600">{dish.note}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Dish gallery detail & phone order modal */}
      {selectedDish && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="dish-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/60 p-4"
          onClick={() => setSelectedDish(null)}
        >
          <div
            className="w-full max-w-md overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="aspect-[4/3] w-full border-b border-stone-200 bg-stone-100">
              <DishArtwork variant={selectedDish.variant} />
            </div>

            <div className="p-6">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-xs font-medium text-zinc-500">
                    {selectedDish.category} <span aria-hidden="true">·</span> Gallery Slot{' '}
                    {selectedDish.slotNumber}
                  </p>
                  <h3
                    id="dish-modal-title"
                    className="mt-1 font-display text-2xl font-bold text-zinc-950"
                  >
                    {selectedDish.title}
                  </h3>
                </div>

                <button
                  type="button"
                  onClick={() => setSelectedDish(null)}
                  aria-label="Close dish preview"
                  className="inline-flex min-h-[40px] min-w-[40px] items-center justify-center rounded-lg border border-stone-200 text-zinc-600 hover:bg-stone-100 hover:text-zinc-950 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-800"
                >
                  <X className="h-4 w-4" aria-hidden="true" />
                </button>
              </div>

              <p className="mt-3 text-sm leading-relaxed text-zinc-600">
                {selectedDish.note}. Ask our kitchen about daily hand-tossed pies and fresh
                appetizer selections when you call to order.
              </p>

              <div className="mt-6 flex flex-col gap-2.5 sm:flex-row">
                <a
                  href={RESTAURANT.phone.href}
                  className="inline-flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-lg bg-red-800 px-4 py-2.5 text-sm font-semibold text-white hover:bg-red-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-800 tabular-nums"
                >
                  <Phone className="h-4 w-4 shrink-0" aria-hidden="true" />
                  <span>Call {RESTAURANT.phone.display}</span>
                </a>
                <button
                  type="button"
                  onClick={() => setSelectedDish(null)}
                  className="inline-flex min-h-[44px] items-center justify-center rounded-lg border border-stone-300 bg-white px-4 py-2.5 text-sm font-medium text-zinc-800 hover:bg-stone-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-800"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
