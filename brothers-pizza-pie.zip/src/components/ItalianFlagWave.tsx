import { useId } from 'react';

interface ItalianFlagBannerProps {
  className?: string;
}

/**
 * Full-width wind-rippled Italian Tricolore ribbon (Green · White · Red from left to right)
 * using compositor-only transform sheen over a sculpted wave path.
 */
export function ItalianFlagBanner({ className = '' }: ItalianFlagBannerProps) {
  const uid = useId().replace(/:/g, '');
  const clipId = `tricolore-wave-clip-${uid}`;
  const foldGradId = `tricolore-fold-grad-${uid}`;

  return (
    <div
      aria-hidden="true"
      className={`relative w-full overflow-hidden select-none ${className}`}
    >
      <svg
        viewBox="0 0 1440 36"
        preserveAspectRatio="none"
        className="block h-5 w-full sm:h-6"
      >
        <defs>
          <clipPath id={clipId}>
            <path d="M0,10 C180,0 360,22 540,12 C720,2 900,22 1080,10 C1230,1 1340,18 1440,10 L1440,26 C1340,34 1230,17 1080,26 C900,36 720,18 540,28 C360,36 180,16 0,26 Z" />
          </clipPath>

          <linearGradient id={foldGradId} x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#000000" stopOpacity="0.14" />
            <stop offset="12.5%" stopColor="#ffffff" stopOpacity="0.26" />
            <stop offset="25%" stopColor="#000000" stopOpacity="0.12" />
            <stop offset="37.5%" stopColor="#ffffff" stopOpacity="0.28" />
            <stop offset="50%" stopColor="#000000" stopOpacity="0.14" />
            <stop offset="62.5%" stopColor="#ffffff" stopOpacity="0.26" />
            <stop offset="75%" stopColor="#000000" stopOpacity="0.12" />
            <stop offset="87.5%" stopColor="#ffffff" stopOpacity="0.28" />
            <stop offset="100%" stopColor="#000000" stopOpacity="0.14" />
          </linearGradient>
        </defs>

        <g clipPath={`url(#${clipId})`}>
          {/* Left-to-right Italian flag bands: Green, White, Red */}
          <rect x="0" y="0" width="480" height="36" fill="#008C45" />
          <rect x="480" y="0" width="480" height="36" fill="#F9FAFB" />
          <rect x="960" y="0" width="480" height="36" fill="#CD212A" />

          {/* Moving cloth highlight/shadow ripples */}
          <rect
            x="0"
            y="0"
            width="2880"
            height="36"
            fill={`url(#${foldGradId})`}
            className="animate-flag-shimmer"
          />
        </g>

        {/* Crisp top & bottom edge contour so white center reads cleanly */}
        <path
          d="M0,10 C180,0 360,22 540,12 C720,2 900,22 1080,10 C1230,1 1340,18 1440,10"
          fill="none"
          stroke="#18181B"
          strokeOpacity="0.08"
          strokeWidth="1"
        />
        <path
          d="M0,26 C180,16 360,36 540,28 C720,18 900,36 1080,26 C1230,17 1340,34 1440,26"
          fill="none"
          stroke="#18181B"
          strokeOpacity="0.1"
          strokeWidth="1"
        />
      </svg>
    </div>
  );
}

interface ItalianFlagEmblemProps {
  className?: string;
}

/**
 * Compact waving Italian flag icon/crest blowing in the wind (Green · White · Red left to right).
 */
export function ItalianFlagEmblem({ className = 'w-16 h-11' }: ItalianFlagEmblemProps) {
  const uid = useId().replace(/:/g, '');
  const clipId = `flag-emblem-clip-${uid}`;
  const foldGradId = `flag-emblem-fold-${uid}`;

  return (
    <svg
      viewBox="0 0 96 64"
      className={`${className} animate-flag-flutter overflow-visible`}
      role="img"
      aria-label="Flag of Italy blowing in the wind: green, white, and red"
    >
      <defs>
        <clipPath id={clipId}>
          <path d="M6,10 C24,2 40,18 58,10 C72,4 82,12 90,8 L90,48 C82,52 72,44 58,50 C40,58 24,42 6,50 Z" />
        </clipPath>
        <linearGradient id={foldGradId} x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#000000" stopOpacity="0.12" />
          <stop offset="16%" stopColor="#ffffff" stopOpacity="0.28" />
          <stop offset="34%" stopColor="#000000" stopOpacity="0.16" />
          <stop offset="50%" stopColor="#ffffff" stopOpacity="0.26" />
          <stop offset="66%" stopColor="#000000" stopOpacity="0.12" />
          <stop offset="84%" stopColor="#ffffff" stopOpacity="0.28" />
          <stop offset="100%" stopColor="#000000" stopOpacity="0.16" />
        </linearGradient>
      </defs>

      <g clipPath={`url(#${clipId})`}>
        <rect x="6" y="0" width="28" height="64" fill="#008C45" />
        <rect x="34" y="0" width="28" height="64" fill="#FFFFFF" />
        <rect x="62" y="0" width="28" height="64" fill="#CD212A" />
        <rect
          x="0"
          y="0"
          width="192"
          height="64"
          fill={`url(#${foldGradId})`}
          className="animate-flag-shimmer"
        />
      </g>

      <path
        d="M6,10 C24,2 40,18 58,10 C72,4 82,12 90,8 L90,48 C82,52 72,44 58,50 C40,58 24,42 6,50 Z"
        fill="none"
        stroke="#18181B"
        strokeOpacity="0.16"
        strokeWidth="1.25"
      />
    </svg>
  );
}
