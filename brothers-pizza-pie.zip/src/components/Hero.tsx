import { useState } from 'react';
import { Clock, MapPin, Phone } from 'lucide-react';
import { getStauntonOpenStatus, RESTAURANT } from '../data/restaurant';
import { ItalianFlagBanner, ItalianFlagEmblem } from './ItalianFlagWave';

export function Hero() {
  const [logoError, setLogoError] = useState(false);
  const status = getStauntonOpenStatus();

  return (
    <section id="top" className="border-b border-stone-200 bg-stone-50">
      <ItalianFlagBanner className="pt-2" />

      <div className="mx-auto grid max-w-6xl grid-cols-1 items-stretch gap-10 px-4 py-10 sm:px-6 sm:py-14 lg:grid-cols-12 lg:gap-12 lg:px-8 lg:py-16">
        {/* Left: Editorial Proposition & Click-to-Call CTA */}
        <div className="flex flex-col justify-center lg:col-span-7">
          <p className="text-sm font-semibold text-[#00703C]">
            Staunton, Virginia <span aria-hidden="true">·</span> Hand-Tossed Pies &amp; Appetizers
          </p>

          <h1
            className="mt-4 font-display font-bold tracking-tight text-zinc-950 text-balance"
            style={{ fontSize: 'clamp(2.25rem, 4.2vw, 3.75rem)', lineHeight: 1.08 }}
          >
            Authentic hand-tossed pies, fresh from our Staunton kitchen.
          </h1>

          <p className="mt-5 max-w-xl text-base leading-relaxed text-zinc-600 sm:text-lg">
            Welcome to {RESTAURANT.name} — a casual neighborhood spot at{' '}
            {RESTAURANT.address.street} specializing in hand-tossed pies and house appetizers.
            All orders are taken fresh by phone.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
            <a
              href={RESTAURANT.phone.href}
              className="inline-flex min-h-[48px] items-center justify-center gap-2.5 rounded-lg bg-red-800 px-6 py-3 text-base font-semibold text-white whitespace-nowrap shrink-0 hover:bg-red-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-800 transition-colors duration-150 tabular-nums"
            >
              <Phone className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span>Call to Order · {RESTAURANT.phone.display}</span>
            </a>

            <a
              href="#location"
              className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-lg border border-[#00703C]/35 bg-white px-5 py-3 text-sm font-semibold text-[#00703C] whitespace-nowrap shrink-0 hover:bg-[#00703C] hover:text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#00703C] transition-colors duration-150"
            >
              <MapPin className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span>Hours &amp; Directions</span>
            </a>
          </div>

          <div className="mt-8 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-sm text-zinc-600 tabular-nums">
            <span className="inline-flex items-center gap-1.5 font-semibold text-[#00703C]">
              <Clock className="h-4 w-4 text-[#00703C]" aria-hidden="true" />
              <span>{status.label}</span>
            </span>
            <span aria-hidden="true">·</span>
            <span>{status.detail}</span>
            <span aria-hidden="true">·</span>
            <span>Phone Orders Only</span>
          </div>
        </div>

        {/* Right: Authentic Heritage Crest & Quick Storefront Info */}
        <div className="lg:col-span-5">
          <div className="flex h-full flex-col justify-between rounded-2xl border border-stone-200 bg-white p-6 sm:p-8">
            <div className="flex items-center justify-between border-b border-stone-200 pb-4">
              <span className="text-xs font-semibold text-[#00703C]">
                Italian Kitchen <span aria-hidden="true">·</span> Staunton, VA
              </span>
              <ItalianFlagEmblem className="h-9 w-14 shrink-0" />
            </div>

            <div className="flex flex-1 items-center justify-center py-6">
              {!logoError ? (
                <img
                  src="/assets/brothers-pizza-logo.png"
                  alt="Brother's Pizza and Italian Restaurant classic crest logo"
                  referrerPolicy="no-referrer"
                  onError={() => setLogoError(true)}
                  className="max-h-40 w-auto max-w-full object-contain"
                />
              ) : (
                <div className="flex flex-col items-center justify-center rounded-xl border border-stone-200 bg-stone-50 px-6 py-10 text-center">
                  <span className="font-display text-2xl font-bold text-red-800">
                    {RESTAURANT.name}
                  </span>
                  <span className="mt-1 text-sm text-emerald-800">
                    {RESTAURANT.tagline}
                  </span>
                </div>
              )}
            </div>

            <div className="border-t border-stone-200 pt-5">
              <dl className="grid grid-cols-1 gap-4 text-sm sm:grid-cols-2">
                <div>
                  <dt className="text-xs font-medium text-zinc-500">Storefront Address</dt>
                  <dd className="mt-1 font-medium text-zinc-900">
                    {RESTAURANT.address.street}
                    <br />
                    {RESTAURANT.address.city}, {RESTAURANT.address.state}{' '}
                    <span className="tabular-nums">{RESTAURANT.address.zip}</span>
                  </dd>
                </div>
                <div>
                  <dt className="text-xs font-medium text-zinc-500">Order by Phone</dt>
                  <dd className="mt-1 font-semibold text-red-800 tabular-nums">
                    <a
                      href={RESTAURANT.phone.href}
                      className="hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-800"
                    >
                      {RESTAURANT.phone.display}
                    </a>
                  </dd>
                  <dd className="mt-0.5 text-xs text-zinc-600">Pickup &amp; local ordering</dd>
                </div>
              </dl>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
