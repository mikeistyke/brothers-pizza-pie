import type { SignatureDishSlot } from '../data/restaurant';

interface DishArtworkProps {
  variant: SignatureDishSlot['variant'];
}

export function DishArtwork({ variant }: DishArtworkProps) {
  switch (variant) {
    case 'classic-pie':
      return (
        <svg
          viewBox="0 0 320 240"
          className="h-full w-full"
          aria-hidden="true"
        >
          <rect width="320" height="240" fill="#F5F5F4" />
          <circle cx="160" cy="120" r="84" fill="#E7E5E4" />
          <circle cx="160" cy="120" r="76" fill="#D97706" fillOpacity="0.22" stroke="#B45309" strokeWidth="3" />
          <circle cx="160" cy="120" r="64" fill="#B91C1C" fillOpacity="0.82" />
          <circle cx="136" cy="96" r="14" fill="#FEF3C7" />
          <circle cx="182" cy="98" r="12" fill="#FEF3C7" />
          <circle cx="152" cy="138" r="15" fill="#FEF3C7" />
          <circle cx="188" cy="136" r="11" fill="#FEF3C7" />
          <circle cx="128" cy="126" r="10" fill="#FEF3C7" />
          <ellipse cx="160" cy="116" rx="7" ry="4" transform="rotate(-25 160 116)" fill="#15803D" />
          <ellipse cx="144" cy="112" rx="6" ry="3.5" transform="rotate(20 144 112)" fill="#15803D" />
          <ellipse cx="174" cy="122" rx="6" ry="3.5" transform="rotate(-15 174 122)" fill="#15803D" />
          <line x1="84" y1="120" x2="236" y2="120" stroke="#78350F" strokeOpacity="0.22" strokeWidth="1.5" />
          <line x1="160" y1="44" x2="160" y2="196" stroke="#78350F" strokeOpacity="0.22" strokeWidth="1.5" />
        </svg>
      );

    case 'pepperoni-pie':
      return (
        <svg
          viewBox="0 0 320 240"
          className="h-full w-full"
          aria-hidden="true"
        >
          <rect width="320" height="240" fill="#F5F5F4" />
          <circle cx="160" cy="120" r="82" fill="#E7E5E4" />
          <circle cx="160" cy="120" r="74" fill="#FDE68A" stroke="#B45309" strokeWidth="4" />
          <circle cx="160" cy="120" r="64" fill="#FEF3C7" />
          <circle cx="132" cy="94" r="11" fill="#991B1B" />
          <circle cx="166" cy="86" r="11" fill="#991B1B" />
          <circle cx="194" cy="108" r="11" fill="#991B1B" />
          <circle cx="124" cy="130" r="11" fill="#991B1B" />
          <circle cx="158" cy="120" r="11" fill="#991B1B" />
          <circle cx="188" cy="142" r="11" fill="#991B1B" />
          <circle cx="144" cy="154" r="11" fill="#991B1B" />
          <line x1="106" y1="68" x2="214" y2="172" stroke="#78350F" strokeOpacity="0.2" strokeWidth="1.5" />
          <line x1="214" y1="68" x2="106" y2="172" stroke="#78350F" strokeOpacity="0.2" strokeWidth="1.5" />
        </svg>
      );

    case 'specialty-pie':
      return (
        <svg
          viewBox="0 0 320 240"
          className="h-full w-full"
          aria-hidden="true"
        >
          <rect width="320" height="240" fill="#F5F5F4" />
          <path d="M160 44 L232 184 Q160 202 88 184 Z" fill="#FDE68A" stroke="#B45309" strokeWidth="3.5" strokeLinejoin="round" />
          <path d="M160 56 L216 168 Q160 182 104 168 Z" fill="#DC2626" fillOpacity="0.8" />
          <path d="M92 178 Q160 198 228 178" fill="none" stroke="#92400E" strokeWidth="9" strokeLinecap="round" />
          <circle cx="156" cy="112" r="12" fill="#FEF3C7" />
          <circle cx="138" cy="144" r="11" fill="#FEF3C7" />
          <circle cx="178" cy="148" r="12" fill="#FEF3C7" />
          <ellipse cx="168" cy="124" rx="8" ry="4" transform="rotate(-35 168 124)" fill="#15803D" />
          <ellipse cx="146" cy="128" rx="7" ry="3.5" transform="rotate(28 146 128)" fill="#15803D" />
        </svg>
      );

    case 'garlic-knots':
      return (
        <svg
          viewBox="0 0 320 240"
          className="h-full w-full"
          aria-hidden="true"
        >
          <rect width="320" height="240" fill="#F5F5F4" />
          <ellipse cx="160" cy="132" rx="96" ry="58" fill="#FFFFFF" stroke="#D6D3D1" strokeWidth="2" />
          <g fill="#FCD34D" stroke="#B45309" strokeWidth="2.5">
            <rect x="96" y="98" width="44" height="28" rx="14" transform="rotate(-12 118 112)" />
            <rect x="144" y="88" width="44" height="28" rx="14" transform="rotate(8 166 102)" />
            <rect x="116" y="128" width="44" height="28" rx="14" transform="rotate(14 138 142)" />
            <rect x="164" y="126" width="44" height="28" rx="14" transform="rotate(-8 186 140)" />
          </g>
          <circle cx="218" cy="108" r="22" fill="#FFFFFF" stroke="#D6D3D1" strokeWidth="2" />
          <circle cx="218" cy="108" r="16" fill="#B91C1C" />
          <circle cx="122" cy="112" r="2.2" fill="#15803D" />
          <circle cx="168" cy="100" r="2.2" fill="#15803D" />
          <circle cx="182" cy="138" r="2.2" fill="#15803D" />
        </svg>
      );

    case 'appetizer-platter':
      return (
        <svg
          viewBox="0 0 320 240"
          className="h-full w-full"
          aria-hidden="true"
        >
          <rect width="320" height="240" fill="#F5F5F4" />
          <rect x="64" y="64" width="192" height="112" rx="22" fill="#FFFFFF" stroke="#D6D3D1" strokeWidth="2" />
          <g fill="#F59E0B" fillOpacity="0.35" stroke="#B45309" strokeWidth="2.5">
            <rect x="86" y="86" width="66" height="18" rx="9" transform="rotate(-10 119 95)" />
            <rect x="88" y="112" width="68" height="18" rx="9" transform="rotate(4 122 121)" />
            <rect x="90" y="138" width="66" height="18" rx="9" transform="rotate(-5 123 147)" />
          </g>
          <circle cx="204" cy="120" r="30" fill="#F5F5F4" stroke="#D6D3D1" strokeWidth="2" />
          <circle cx="204" cy="120" r="22" fill="#B91C1C" />
          <ellipse cx="204" cy="116" rx="5" ry="3" fill="#15803D" />
        </svg>
      );

    case 'baked-starter':
      return (
        <svg
          viewBox="0 0 320 240"
          className="h-full w-full"
          aria-hidden="true"
        >
          <rect width="320" height="240" fill="#F5F5F4" />
          <ellipse cx="160" cy="124" rx="92" ry="62" fill="#FFFFFF" stroke="#D6D3D1" strokeWidth="2" />
          <ellipse cx="160" cy="124" rx="74" ry="46" fill="#DC2626" fillOpacity="0.14" stroke="#991B1B" strokeWidth="2" />
          <path
            d="M104 126 Q160 76 216 126 Q160 156 104 126 Z"
            fill="#FDE68A"
            stroke="#B45309"
            strokeWidth="3"
          />
          <line x1="138" y1="104" x2="146" y2="124" stroke="#92400E" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="160" y1="98" x2="162" y2="122" stroke="#92400E" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="182" y1="104" x2="176" y2="124" stroke="#92400E" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      );
  }
}
