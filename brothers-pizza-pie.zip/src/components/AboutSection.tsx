import { useState } from 'react';
import { History, X } from 'lucide-react';
import { RESTAURANT } from '../data/restaurant';
import { ItalianFlagEmblem } from './ItalianFlagWave';

export function AboutSection() {
  const [showArchiveModal, setShowArchiveModal] = useState(false);
  const [archiveImgError, setArchiveImgError] = useState(false);

  return (
    <section id="about" className="border-b border-stone-200 bg-stone-50">
      <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-18 lg:px-8 lg:py-20">
        <div className="grid grid-cols-1 items-stretch gap-8 lg:grid-cols-12 lg:gap-12">
          {/* Left: Heritage & Original 2008 Site Context */}
          <div className="flex flex-col justify-between rounded-2xl border border-stone-200 bg-white p-6 sm:p-8 lg:col-span-5">
            <div>
              <div className="flex items-center justify-between gap-4">
                <p className="text-sm font-semibold text-[#00703C]">Since Our 2008 Site</p>
                <ItalianFlagEmblem className="h-8 w-12 shrink-0" />
              </div>
              <h2 className="mt-2 font-display text-2xl font-bold tracking-tight text-zinc-950 sm:text-3xl text-balance">
                A Fresh Chapter for {RESTAURANT.name}
              </h2>
              <p className="mt-3 text-sm leading-relaxed text-zinc-600">
                First online as {RESTAURANT.heritageName} in 2008, now redesigned with a
                mobile-first layout so Staunton guests can check hours, find directions, and
                call in an order in seconds.
              </p>
            </div>

            <div className="mt-8 border-t border-stone-200 pt-6">
              <button
                type="button"
                onClick={() => setShowArchiveModal(true)}
                className="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-[#00703C]/35 bg-stone-50 px-4 py-2.5 text-sm font-medium text-[#00703C] hover:bg-[#00703C] hover:text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#00703C] transition-colors duration-150"
              >
                <History className="h-4 w-4" aria-hidden="true" />
                <span>View Original 2008 Site Snapshot</span>
              </button>
            </div>
          </div>

          {/* Right: Dedicated Family Story Placeholder (Zero Invented Backstory) */}
          <div className="flex flex-col justify-center rounded-2xl border border-stone-200 bg-white p-6 sm:p-10 lg:col-span-7">
            <p className="text-sm font-medium text-red-800">Our Story</p>
            <h3 className="mt-2 font-display text-2xl font-bold tracking-tight text-zinc-950 sm:text-3xl text-balance">
              {RESTAURANT.aboutPlaceholder.heading}
            </h3>
            <p className="mt-2 text-sm font-medium text-zinc-500">
              {RESTAURANT.aboutPlaceholder.lead}
            </p>

            <div className="mt-6 space-y-4 text-base leading-relaxed text-zinc-700">
              {RESTAURANT.aboutPlaceholder.paragraphs.map((paragraph, index) => (
                <p key={index} className="rounded-lg bg-stone-50 p-4 text-zinc-700">
                  {paragraph}
                </p>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Original 2008 Snapshot Modal */}
      {showArchiveModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="archive-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/65 p-4"
          onClick={() => setShowArchiveModal(false)}
        >
          <div
            className="w-full max-w-lg overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-stone-200 px-6 py-4">
              <div>
                <h3
                  id="archive-modal-title"
                  className="font-display text-lg font-bold text-zinc-950"
                >
                  Original 2008 Website Archive
                </h3>
                <p className="text-xs text-zinc-500">{RESTAURANT.heritageName}</p>
              </div>
              <button
                type="button"
                onClick={() => setShowArchiveModal(false)}
                aria-label="Close archive snapshot"
                className="inline-flex min-h-[40px] min-w-[40px] items-center justify-center rounded-lg border border-stone-200 text-zinc-600 hover:bg-stone-100 hover:text-zinc-950 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-800"
              >
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>

            <div className="max-h-[70vh] overflow-y-auto bg-stone-100 p-4">
              {!archiveImgError ? (
                <img
                  src="/assets/aistudio/pic_old_site_ued_for_new_site_e7e9c9dd.jpeg"
                  alt="Screenshot of the original 2008 Brother's Pizza & Italian Restaurant website"
                  referrerPolicy="no-referrer"
                  onError={() => setArchiveImgError(true)}
                  className="mx-auto max-h-[60vh] w-auto rounded-lg border border-stone-200 object-contain"
                />
              ) : (
                <div className="flex h-48 items-center justify-center rounded-lg border border-stone-200 bg-white p-6 text-center text-sm text-zinc-600">
                  Original 2008 website archive image unavailable.
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
