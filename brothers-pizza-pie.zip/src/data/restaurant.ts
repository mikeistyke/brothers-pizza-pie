export const RESTAURANT = {
  name: 'Brothers Pizza',
  domain: 'brotherspizzapie.com',
  heritageName: "Brother's Pizza & Italian Restaurant",
  tagline: 'Authentic hand-tossed pies & appetizers',
  architect: {
    name: 'Tyke Cirigliano',
    agency: 'vibinginva.com',
    url: 'https://vibinginva.com',
  },
  address: {
    street: '74 Orchard Hill Circle, Suite 110',
    city: 'Staunton',
    state: 'VA',
    zip: '24401',
    full: '74 Orchard Hill Circle, Suite 110, Staunton, VA 24401',
    mapsUrl:
      'https://www.google.com/maps/search/?api=1&query=74+Orchard+Hill+Circle+Suite+110,+Staunton,+VA+24401',
  },
  phone: {
    display: '(540) 885-8787',
    raw: '+15408858787',
    href: 'tel:+15408858787',
  },
  hours: [
    {
      label: 'Mon – Thu',
      days: [1, 2, 3, 4],
      display: '11:00 AM – 10:00 PM',
      openMinutes: 11 * 60,
      closeMinutes: 22 * 60,
    },
    {
      label: 'Fri – Sat',
      days: [5, 6],
      display: '11:00 AM – 11:00 PM',
      openMinutes: 11 * 60,
      closeMinutes: 23 * 60,
    },
    {
      label: 'Sun',
      days: [0],
      display: '12:00 PM – 10:00 PM',
      openMinutes: 12 * 60,
      closeMinutes: 22 * 60,
    },
  ],
  aboutPlaceholder: {
    heading: 'Family-Owned in Staunton, Virginia',
    lead: 'Placeholder for your family-owned story — ready for your own words before launch.',
    paragraphs: [
      '[Placeholder Paragraph 1: Share how your family started Brothers Pizza, what inspired your recipes, and the care that goes into stretching every hand-tossed pie and preparing each appetizer to order.]',
      '[Placeholder Paragraph 2: Tell neighbors and visitors in Staunton what makes dining or picking up at 74 Orchard Hill Circle, Suite 110 feel like home — from longtime regulars to new faces stopping by for a fresh pie.]',
    ],
  },
} as const;

export type DishCategory = 'All' | 'Hand-Tossed Pies' | 'Appetizers';

export interface SignatureDishSlot {
  id: string;
  slotNumber: string;
  category: Exclude<DishCategory, 'All'>;
  title: string;
  note: string;
  variant: 'classic-pie' | 'pepperoni-pie' | 'specialty-pie' | 'garlic-knots' | 'appetizer-platter' | 'baked-starter';
}

export const SIGNATURE_DISHES: SignatureDishSlot[] = [
  {
    id: 'dish-01',
    slotNumber: '01',
    category: 'Hand-Tossed Pies',
    title: 'Signature Pie I',
    note: 'Photo slot ready for your featured hand-tossed pie',
    variant: 'classic-pie',
  },
  {
    id: 'dish-02',
    slotNumber: '02',
    category: 'Hand-Tossed Pies',
    title: 'Signature Pie II',
    note: 'Photo slot ready for your classic topped pie',
    variant: 'pepperoni-pie',
  },
  {
    id: 'dish-03',
    slotNumber: '03',
    category: 'Appetizers',
    title: 'House Appetizer I',
    note: 'Photo slot ready for your signature starter',
    variant: 'garlic-knots',
  },
  {
    id: 'dish-04',
    slotNumber: '04',
    category: 'Hand-Tossed Pies',
    title: 'Signature Pie III',
    note: 'Photo slot ready for a house specialty pie',
    variant: 'specialty-pie',
  },
  {
    id: 'dish-05',
    slotNumber: '05',
    category: 'Appetizers',
    title: 'House Appetizer II',
    note: 'Photo slot ready for your shareable appetizer plate',
    variant: 'appetizer-platter',
  },
  {
    id: 'dish-06',
    slotNumber: '06',
    category: 'Appetizers',
    title: 'House Appetizer III',
    note: 'Photo slot ready for an oven-baked favorite',
    variant: 'baked-starter',
  },
];

export interface OpenStatus {
  isOpen: boolean;
  label: string;
  detail: string;
}

export function getStauntonOpenStatus(now: Date = new Date()): OpenStatus {
  try {
    const formatter = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/New_York',
      weekday: 'short',
      hour: 'numeric',
      minute: 'numeric',
      hour12: false,
    });
    const parts = formatter.formatToParts(now);
    const weekdayStr = parts.find((p) => p.type === 'weekday')?.value ?? 'Mon';
    const hour = Number(parts.find((p) => p.type === 'hour')?.value ?? '12') % 24;
    const minute = Number(parts.find((p) => p.type === 'minute')?.value ?? '0');

    const dayMap: Record<string, number> = {
      Sun: 0,
      Mon: 1,
      Tue: 2,
      Wed: 3,
      Thu: 4,
      Fri: 5,
      Sat: 6,
    };
    const dayIndex = dayMap[weekdayStr] ?? 1;
    const minutesNow = hour * 60 + minute;

    const todaySchedule = RESTAURANT.hours.find((h) =>
      (h.days as readonly number[]).includes(dayIndex)
    );

    if (!todaySchedule) {
      return {
        isOpen: false,
        label: 'Check Hours',
        detail: 'Call (540) 885-8787 for today’s hours',
      };
    }

    if (minutesNow >= todaySchedule.openMinutes && minutesNow < todaySchedule.closeMinutes) {
      const closeHour = Math.floor(todaySchedule.closeMinutes / 60);
      const displayClose = closeHour > 12 ? `${closeHour - 12}:00 PM` : `${closeHour}:00 AM`;
      return {
        isOpen: true,
        label: 'Open Now',
        detail: `Closes at ${displayClose} ET`,
      };
    }

    if (minutesNow < todaySchedule.openMinutes) {
      const openHour = Math.floor(todaySchedule.openMinutes / 60);
      const displayOpen =
        openHour === 12
          ? '12:00 PM'
          : openHour > 12
            ? `${openHour - 12}:00 PM`
            : `${openHour}:00 AM`;
      return {
        isOpen: false,
        label: 'Currently Closed',
        detail: `Opens today at ${displayOpen} ET`,
      };
    }

    return {
      isOpen: false,
      label: 'Closed for Today',
      detail: 'See weekly schedule below',
    };
  } catch {
    return {
      isOpen: true,
      label: 'Staunton Kitchen',
      detail: 'Open daily · See schedule below',
    };
  }
}
