/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AboutSection } from './components/AboutSection';
import { Footer } from './components/Footer';
import { Hero } from './components/Hero';
import { HoursLocation } from './components/HoursLocation';
import { Navbar } from './components/Navbar';
import { OrderCta } from './components/OrderCta';
import { SignatureDishes } from './components/SignatureDishes';

export default function App() {
  return (
    <div className="min-h-screen bg-stone-50 text-zinc-900">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-red-800 focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-white"
      >
        Skip to main content
      </a>

      <Navbar />

      <main id="main-content">
        <Hero />
        <SignatureDishes />
        <AboutSection />
        <HoursLocation />
        <OrderCta />
      </main>

      <Footer />
    </div>
  );
}
